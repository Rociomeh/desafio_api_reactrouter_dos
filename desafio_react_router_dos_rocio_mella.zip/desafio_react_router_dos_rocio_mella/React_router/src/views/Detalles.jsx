import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function Detalles() {
    const [pokemon, setPokemon] = useState(null);
    const { id } = useParams();

    useEffect(() => {
        fetch(`https://pokeapi.co/api/v2/pokemon/${id}`)
            .then(res => res.json())
            .then(data => setPokemon(data))
            .catch(error => console.error(error));
    }, [id]);

    if (!pokemon) {
        return <div>Cargando...</div>;
    }

    const imageUrl = pokemon.sprites.other["official-artwork"].front_default;

    return (
        <>
            <h1>{`#${pokemon.id} ${pokemon.name.toUpperCase()}`}</h1>
            <img src={imageUrl} alt={pokemon.name} />
            <h2>Estadísticas</h2>
            <ul>
                {pokemon.stats.map(stat => (
                    <li key={stat.stat.name}>
                        {stat.stat.name}: {stat.base_stat}
                    </li>
                ))}
            </ul>
            <h2>Ataques</h2>
            <ul>
                {pokemon.moves.slice(0, 10).map(move => (
                    <li key={move.move.name}>{move.move.name}</li>
                ))}
            </ul>
            <h2>Tipo(s)</h2>
            <ul>
                {pokemon.types.map(type => (
                    <li key={type.type.name}>{type.type.name}</li>
                ))}
            </ul>
        </>
    );
}

export default Detalles;