import React from "react";

function Home () {
    
    return(

    <div>
        <h1>Bienvenido maestro pokemón</h1>
        <img src="https://i.pinimg.com/originals/76/47/9d/76479dd91dc55c2768ddccfc30a4fbf5.png" />
    </div>
    )
}

export default Home;