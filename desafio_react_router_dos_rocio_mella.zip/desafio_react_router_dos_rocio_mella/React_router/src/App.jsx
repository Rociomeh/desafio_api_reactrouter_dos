import './App.css'
import Navbar from './components/Navbar'
import Home from './views/Home';
import Personajes from './views/PersonajesContext';
import Detalles from './views/Detalles';
import { Routes, Route } from 'react-router-dom';

function App() {

  return(  
  <>
    <Navbar />
    <Routes>
      <Route path='/' element={<Home/>}/>
      <Route path='/personajes' element={<Personajes/>} />
      <Route path='/detalles/:id' element={<Detalles/>} />
    </Routes>
  </>
  )

}

export default App;